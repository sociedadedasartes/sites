<?php
/**
 * Plugin Name: YouTube Playlist Gallery
 * Description: Exibe um player do YouTube com miniaturas da playlist via shortcode [youtube_playlist_gallery playlist_id="..."].
 * Version: 1.3.1
 * Author: Henrique Vieira Filho + ChatGPT
 * Text Domain: ytpg
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) exit;

function ytpg_load_textdomain() {
    load_plugin_textdomain('ytpg', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'ytpg_load_textdomain');

function ytpg_enqueue_scripts() {
    wp_enqueue_style('ytpg-style', plugin_dir_url(__FILE__) . 'style.css');
    wp_enqueue_script('ytpg-script', plugin_dir_url(__FILE__) . 'script.js', array(), null, true);

    wp_localize_script('ytpg-script', 'ytpgData', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
    ));
}
add_action('wp_enqueue_scripts', 'ytpg_enqueue_scripts');

function ytpg_shortcode($atts) {
    $atts = shortcode_atts(array(
        'playlist_id' => get_option('ytpg_playlist_id', ''),
    ), $atts);

    ob_start();
    ?>
    <div class="youtube-gallery-container" data-playlist-id="<?php echo esc_attr($atts['playlist_id']); ?>">
        <div id="youtube-player"></div>
        <div class="youtube-thumbnails" id="youtube-thumbnails"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('youtube_playlist_gallery', 'ytpg_shortcode');

function ytpg_get_playlist_data() {
    $playlist_id = sanitize_text_field($_GET['playlist_id']);
    $api_key = get_option('ytpg_api_key', '');
    $transient_key = 'ytpg_cache_' . md5($playlist_id);

    if (false === ($data = get_transient($transient_key))) {
        $data = [];
        $page_token = '';
        do {
            $url = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId={$playlist_id}&key={$api_key}&pageToken={$page_token}";
            $response = wp_remote_get($url);
            if (is_wp_error($response)) break;
            $body = wp_remote_retrieve_body($response);
            $result = json_decode($body, true);
            if (isset($result['items'])) {
                $data = array_merge($data, $result['items']);
                $page_token = isset($result['nextPageToken']) ? $result['nextPageToken'] : '';
            } else {
                break;
            }
        } while (!empty($page_token));

        set_transient($transient_key, $data, HOUR_IN_SECONDS);
    }

    wp_send_json($data);
}
add_action('wp_ajax_ytpg_get_playlist_data', 'ytpg_get_playlist_data');
add_action('wp_ajax_nopriv_ytpg_get_playlist_data', 'ytpg_get_playlist_data');

function ytpg_add_settings_menu() {
    add_options_page(
        __('YouTube Playlist Gallery Settings', 'ytpg'),
        __('YouTube Playlist Gallery', 'ytpg'),
        'manage_options',
        'ytpg-settings',
        'ytpg_render_settings_page'
    );
}
add_action('admin_menu', 'ytpg_add_settings_menu');

function ytpg_render_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('YouTube Playlist Gallery - Settings', 'ytpg'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ytpg_settings_group');
            do_settings_sections('ytpg-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function ytpg_register_settings() {
    register_setting('ytpg_settings_group', 'ytpg_api_key');
    register_setting('ytpg_settings_group', 'ytpg_playlist_id');

    add_settings_section('ytpg_main_section', __('API Settings', 'ytpg'), null, 'ytpg-settings');

    add_settings_field('ytpg_api_key', __('YouTube API Key', 'ytpg'), 'ytpg_api_key_field', 'ytpg-settings', 'ytpg_main_section');
    add_settings_field('ytpg_playlist_id', __('Default Playlist ID', 'ytpg'), 'ytpg_playlist_id_field', 'ytpg-settings', 'ytpg_main_section');
}
add_action('admin_init', 'ytpg_register_settings');

function ytpg_api_key_field() {
    $value = esc_attr(get_option('ytpg_api_key', ''));
    echo "<input type='text' name='ytpg_api_key' value='$value' class='regular-text' />";
}

function ytpg_playlist_id_field() {
    $value = esc_attr(get_option('ytpg_playlist_id', ''));
    echo "<input type='text' name='ytpg_playlist_id' value='$value' class='regular-text' />";
}
