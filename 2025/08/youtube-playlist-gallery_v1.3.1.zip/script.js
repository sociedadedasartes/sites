document.addEventListener('DOMContentLoaded', function () {
  let player;
  let primeiroVideoCarregado = false;

  const tag = document.createElement('script');
  tag.src = "https://www.youtube.com/iframe_api";
  document.body.appendChild(tag);

  const container = document.querySelector('.youtube-gallery-container');
  const playlistId = container?.dataset.playlistId;

  if (!playlistId) {
    console.error("YT Playlist Gallery: playlistId ausente.");
    return;
  }

  window.onYouTubeIframeAPIReady = function () {
    player = new YT.Player('youtube-player', {
      height: '500',
      width: '100%',
      videoId: '',
      playerVars: {
        rel: 0,
        showinfo: 0
      }
    });

    carregarVideos(playlistId);
  };

  async function carregarVideos(playlistId) {
    try {
      const res = await fetch(`${ytpgData.ajaxurl}?action=ytpg_get_playlist_data&playlist_id=${playlistId}`);
      const data = await res.json();
      console.log("YT Playlist Gallery: dados carregados", data);

      const thumbs = document.getElementById('youtube-thumbnails');
      thumbs.innerHTML = '';

      data.forEach((item, index) => {
        if (!item.snippet || !item.snippet.thumbnails || !item.snippet.resourceId) {
          console.warn("YT Playlist Gallery: item inválido", item);
          return;
        }

        const videoId = item.snippet.resourceId.videoId;
        const thumbUrl = item.snippet.thumbnails.medium.url;
        const title = item.snippet.title;

        const div = document.createElement('div');
        div.className = 'youtube-thumb';
        div.innerHTML = `<img src="${thumbUrl}" alt="${title}" title="${title}">`;
        div.onclick = () => {
          player.loadVideoById(videoId);
        };
        thumbs.appendChild(div);

        if (!primeiroVideoCarregado) {
          setTimeout(() => player.cueVideoById(videoId), 500);
          primeiroVideoCarregado = true;
        }
      });

      if (!primeiroVideoCarregado) {
        console.warn("YT Playlist Gallery: nenhum vídeo foi carregado.");
      }
    } catch (err) {
      console.error('YT Playlist Gallery: erro ao carregar vídeos da playlist', err);
    }
  }
});
