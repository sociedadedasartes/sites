<?php
/*
Plugin Name: Acervo Dinâmico Sociedade das Artes
Plugin URI: https://livroteca.com.br
Description: Versão 3.4 - Retorno à alta velocidade com botão automático e contador.
Version: 3.4
Author: Henrique Vieira Filho
*/

if (!defined('ABSPATH')) exit;

if (!class_exists('Acervo_SA_Veloz')) {

    class Acervo_SA_Veloz {
        
        public function __construct() {
            add_shortcode('acervo', array($this, 'v34_executar'));
            add_action('wp_enqueue_scripts', array($this, 'v34_assets'));
            add_action('admin_menu', array($this, 'v34_menu'));
        }

        public function v34_assets() {
            wp_register_script('f-js-sa', 'https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js', array(), '5.0', true);
            wp_register_style('f-css-sa', 'https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css');
        }

        public function v34_menu() {
            add_menu_page('Ajuda Acervo', 'Ajuda Acervo', 'manage_options', 'ajuda-acervo', function() {
                echo '<div class="wrap"><h1>Manual do Acervo v3.4</h1><p>Código: <code>[acervo url="LINK" legenda="Título"]</code></p></div>';
            }, 'dashicons-art', 100);
        }

        public function v34_executar($atts) {
            $atts = shortcode_atts(array('url' => '', 'legenda' => ''), $atts);
            if (empty($atts['url'])) return "";

            $token = md5($atts['url']);
            $cache_key = 'gac_v34_' . $token;

            if (isset($_GET['refresh']) || (is_user_logged_in() && current_user_can('manage_options'))) {
                delete_transient($cache_key);
            }

            $links = get_transient($cache_key);
            if (false === $links) {
                $links = $this->v34_buscar_veloz($atts['url']);
                if (!empty($links)) set_transient($cache_key, $links, 12 * HOUR_IN_SECONDS);
            }

            if (empty($links)) return "Sincronizando... Atualize a página.";

            wp_enqueue_script('f-js-sa');
            wp_enqueue_style('f-css-sa');

            $total = count($links);
            $gid = 'gal_' . substr($token, 0, 8);
            
            ob_start(); ?>
            <style>
                .sa_header { display: flex; justify-content: space-between; align-items: center; margin: 25px 0 15px; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
                .sa_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 10px; }
                .sa_item { height: 170px; background: #000; border: 1px solid #ccc; overflow: hidden; border-radius: 4px; }
                .sa_item img { width: 100%; height: 100%; object-fit: cover; cursor: pointer; transition: 0.3s; }
                .sa_item img:hover { transform: scale(1.05); }
                .sa_btn { background: #4285F4; color: #fff !important; padding: 6px 14px; border-radius: 20px; font-size: 11px; text-decoration: none !important; font-weight: bold; }
            </style>
            <div class="sa_wrap">
                <div class="sa_header">
                    <div>
                        <h3 style="margin:0;"><?php echo esc_html($atts['legenda']); ?></h3>
                        <small style="color:#666;"><?php echo $total; ?> obras localizadas</small>
                    </div>
                    <a href="<?php echo esc_url($atts['url']); ?>" target="_blank" class="sa_btn">ABRIR ÁLBUM ORIGINAL</a>
                </div>
                <div class="sa_grid">
                    <?php foreach ($links as $f): ?>
                        <div class="sa_item"><a href="<?php echo $f; ?>=w2048" data-fancybox="<?php echo $gid; ?>"><img src="<?php echo $f; ?>=w400" loading="lazy"></a></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <script>document.addEventListener("DOMContentLoaded", function() { if (window.Fancybox) { Fancybox.bind("[data-fancybox='<?php echo $gid; ?>']", { infinite: true, loop: true }); } });</script>
            <?php return ob_get_clean();
        }

        private function v34_buscar_veloz($url) {
            @ini_set('memory_limit', '512M');
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url . '?t=' . time());
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
            $html = curl_exec($ch);
            curl_close($ch);

            if (!$html) return array();

            $urls = array();
            // Volta para o método de explosão: rápido e leve
            $prefixos = array('https://lh3.googleusercontent.com/pw/', 'https://lh3.googleusercontent.com/a/');
            foreach ($prefixos as $pre) {
                $partes = explode($pre, $html);
                for ($i = 1; $i < count($partes); $i++) {
                    if (preg_match('/^[a-zA-Z0-9\-_]+/', $partes[$i], $match)) {
                        if (strlen($match[0]) > 80) $urls[] = $pre . $match[0];
                    }
                }
            }
            return array_values(array_unique($urls));
        }
    }
    new Acervo_SA_Veloz();
}